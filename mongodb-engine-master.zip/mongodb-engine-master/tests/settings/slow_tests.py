from settings import *


INSTALLED_APPS = DEFAULT_APPS + ['django.contrib.contenttypes', 'multiple_database']
ROOT_URLCONF = ''
TEST_RUNNER = 'djangotoolbox.test.NonrelTestSuiteRunner'
