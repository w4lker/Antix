"""Stolen from the Django testsuite, shaked down for m2m tests."""
