Meta
====

.. toctree::
   :maxdepth: 1

   changelog
   contributing
   authors
