from django_mongodb_engine.storage import GridFSStorage


gridfs_storage = GridFSStorage()
