DATABASES = {
    'default': {
        'ENGINE': 'django_mongodb_engine',
        'NAME': 'mapreduce',
    },
}

INSTALLED_APPS = ['mr']
