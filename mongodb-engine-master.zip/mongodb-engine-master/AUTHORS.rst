Authors
=======

Current Primary Authors
-----------------------
* Jonas Haag <jonas@lophus.org>
* Flavio Percoco Premoli <flaper87@flaper87.org>
* Wojtek Ruszczewski <github@wr.waw.pl>

Past Primary Authors
--------------------
* Alberto Paro <alberto@ingparo.it>
* George Karpenkov <george@metaworld.ru>

Contributions by
----------------
* Ellie Frost (https://github.com/stillinbeta)
* Simon Charette (https://github.com/charettes)
* Dag Stockstad (https://github.com/dstockstad) -- found tons of bugs in our query generator
* Shane R. Spencer (https://github.com/whardier) -- Website Review
* Sabin Iacob (https://github.com/m0n5t3r)
* kryton (https://github.com/kryton)
* Brandon Pedersen (https://github.com/bpedman)

(For an up-to-date list of contributors, see
https://github.com/django-nonrel/mongodb-engine/contributors.)
