djangotoolbox
-------------

Utility functions for django-nonrel