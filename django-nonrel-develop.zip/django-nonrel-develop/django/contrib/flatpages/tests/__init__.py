from django.contrib.flatpages.tests.csrf import *
from django.contrib.flatpages.tests.forms import *
from django.contrib.flatpages.tests.middleware import *
from django.contrib.flatpages.tests.templatetags import *
from django.contrib.flatpages.tests.views import *
